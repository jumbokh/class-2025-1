#!/usr/bin/env bash
set -euo pipefail

BASE=${1:-http://127.0.0.1:8010}

echo "[1/2] health ..."
curl -sS ${BASE}/health | jq . || true

echo "[2/2] stats ..."
curl -sS ${BASE}/report/stats | jq . || true

echo "Done."
