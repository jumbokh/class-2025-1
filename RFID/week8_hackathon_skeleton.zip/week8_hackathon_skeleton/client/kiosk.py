"""
最小 Kiosk 範例（離線優先）：
- 本地 card_store.json 保存餘額 / last_txn_no / journal
- 優先嘗試線上購買，失敗則寫入 journal（待 /reconcile）
請依題目修改為門禁、借還或打卡等流程。
"""
import os, json, time, requests
from pathlib import Path

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8010")
STORE = Path(__file__).parent / "card_store.json"

def load_store():
    if STORE.exists(): return json.loads(STORE.read_text("utf-8"))
    return {"uid":"04aa11bb","balance":100,"last_txn_no":0,"journal":[]}

def save_store(d): STORE.write_text(json.dumps(d, ensure_ascii=False, indent=2), "utf-8")

def buy(amount: int):
    d = load_store()
    txn_no = max(int(d.get("last_txn_no",0))+1, int(time.time()))
    try:
        r = requests.post(f"{SERVER_URL}/wallet/purchase",
                          json={"uid": d["uid"], "amount": amount, "txn_no": txn_no},
                          timeout=3)
        data = r.json()
        if data.get("ok"):
            d["last_txn_no"] = txn_no
            d["balance"] = data.get("balance", d["balance"])
            save_store(d)
            print("線上成功：", data); return True
        raise RuntimeError(data.get("reason","unknown"))
    except Exception as e:
        if d["balance"] - amount < 0:
            print("離線不足額，取消"); return False
        d["balance"] -= amount
        d["last_txn_no"] = txn_no
        d["journal"].append({"uid": d["uid"], "type":"PURCHASE", "amount": -amount,
                             "txn_no": txn_no, "ts": int(time.time())})
        save_store(d)
        print("離線記帳完成，等待對帳。")
        return True

if __name__ == "__main__":
    buy(20)
