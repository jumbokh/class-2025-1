import os, requests, streamlit as st

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8010")
st.set_page_config(page_title="Week 8 MVP 看板", layout="wide")
st.title("Week 8｜MVP 看板")

col1, col2 = st.columns(2)

with col1:
    st.subheader("健康檢查")
    try:
        data = requests.get(f"{SERVER_URL}/health", timeout=5).json()
        st.write(data)
    except Exception as e:
        st.error(f"health 失敗：{e}")

with col2:
    st.subheader("近 24h 事件數")
    try:
        stats = requests.get(f"{SERVER_URL}/report/stats", timeout=5).json()
        st.write(stats)
    except Exception as e:
        st.error(f"stats 失敗：{e}")

st.caption("請依題目擴充更多報表（交易額、逾期、在線人數…）")
