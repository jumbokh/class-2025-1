import os, time
from flask import Flask, jsonify, request
from utils.db import get_conn

app = Flask(__name__)

@app.get("/health")
def health():
    return jsonify({"ok": True, "ts": int(time.time())})

# ------------------ TODO: 依題目擴充 ------------------
# 範例錢包購買（請自行完成邏輯 / 去重 / 扣款保護）
@app.post("/wallet/purchase")
def wallet_purchase():
    return jsonify({"ok": False, "todo": "implement /wallet/purchase"}), 501

# 範例對帳端點（離線 journal → 補帳）
@app.post("/wallet/reconcile")
def wallet_reconcile():
    return jsonify({"ok": False, "todo": "implement /wallet/reconcile"}), 501

# 範例借出 / 歸還
@app.post("/loan/checkout")
def loan_checkout():
    return jsonify({"ok": False, "todo": "implement /loan/checkout"}), 501

@app.post("/loan/return")
def loan_return():
    return jsonify({"ok": False, "todo": "implement /loan/return"}), 501

# 報表示例：回傳近 24 小時事件數（請依題目改寫）
@app.get("/report/stats")
def report_stats():
    try:
        now = int(time.time())
        day_ago = now - 24*3600
        with get_conn() as conn, conn.cursor() as c:
            c.execute("SELECT COUNT(*) AS cnt FROM events WHERE ts BETWEEN %s AND %s", (day_ago, now))
            cnt = c.fetchone()["cnt"]
        return jsonify({"ok": True, "window":"24h", "events": int(cnt)})
    except Exception as e:
        return jsonify({"ok": False, "reason": str(e)}), 500

if __name__ == "__main__":
    host=os.getenv("HOST","0.0.0.0")
    port=int(os.getenv("PORT","8010"))
    app.run(host=host, port=port, debug=True)
