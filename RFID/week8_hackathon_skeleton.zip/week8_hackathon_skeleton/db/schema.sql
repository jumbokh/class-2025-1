CREATE DATABASE IF NOT EXISTS rfid_iot DEFAULT CHARACTER SET utf8mb4;
USE rfid_iot;

-- 通用事件表（可作為示範/占位，請依題目擴充）
CREATE TABLE IF NOT EXISTS events(
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  uid VARCHAR(32) NOT NULL,
  type VARCHAR(32) NOT NULL,        -- e.g. CHECKIN / PURCHASE / CHECKOUT / RETURN
  amount INT DEFAULT 0,             -- 僅在錢包場景使用
  op_no BIGINT NOT NULL,            -- 用於去重（反重送）
  ts BIGINT NOT NULL,
  UNIQUE KEY uniq_uid_op (uid, op_no)
);

-- 建議依題目新增：
-- users(uid PK, name, dept, status)
-- cards(uid PK, server_balance, last_txn_no)
-- assets(tag_uid PK, name, status, ...)
-- loans(id, tag_uid, borrower_uid, checkout_ts, due_ts, return_ts, op_no, ...)
-- inventory_session / inventory_event
