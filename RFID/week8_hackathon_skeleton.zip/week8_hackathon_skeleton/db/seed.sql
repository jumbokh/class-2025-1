USE rfid_iot;

-- 這裡放入示例資料（視題目調整或留空）
-- INSERT INTO users(uid,name,dept,status) VALUES ('04aa11bb','Student A','AI',1);
-- INSERT INTO assets(tag_uid,name,status) VALUES ('A100aa01','Laptop-01','IN');
