# Week 8｜創作黑客松：RFID × IoT MVP 空專案

本骨架整合了第 5–7 週的核心套路（門禁 / 電子錢包 / 資產出借＋盤點），方便小組直接開發 **MVP**。

## 一、專案結構
```
db/                 # 資料表 SQL、示例資料
server/             # Flask API（健康檢查 + 報表 + 待實作的路由）
  utils/db.py
client/             # Kiosk / 對帳 客戶端範例（可離線 journal）
web/                # Dashboard（Streamlit）
tests/              # 煙霧測試腳本與 Postman 集合
docs/               # 評分表（教師用）、說明文件
.env.sample         # 參考環境變數
requirements.txt
```

## 二、快速開始（5 步）
1) 建立虛擬環境並安裝：
```bash
pip install -r requirements.txt
cp .env.sample .env
```
2) 建資料庫（可從空表開始）：
```bash
mysql -u root -p < db/schema.sql
mysql -u root -p < db/seed.sql   # 可選
```
3) 啟動後端：
```bash
python server/app.py
# http://127.0.0.1:8010/health  應回 200 {"ok":true}
```
4) 開啟 Dashboard（可選）：
```bash
streamlit run web/dashboard.py
```
5) 跑一次煙霧測試：
```bash
bash tests/curl_smoke.sh
# 或用 tests/postman_collection.json 匯入 Postman 跑集合
```

## 三、建議題目（至少整合 2 個能力）
- 多門禁 + 訪客管理／臨時卡
- 電子錢包 + 對帳（離線 journal → /reconcile）
- 資產出借 + 逾期通知 + 盤點摘要
- 校園活動打卡 + 勳章 + 榜單

## 四、MVP 核心檢核
- 去重：唯一索引（如 `(uid, txn_no)` or `op_no`）
- 資料一致性：不可透支、不可重複借出、反重送
- 報表 / 看板：至少 1 份 24h 統計
- 文件完整：README、.env.sample、SQL 或遷移腳本、測試腳本
- Demo：60–90 秒影片（流程）

更多細節與評分規準見 `docs/rubric.md` 與 `docs/評分表_教師用.csv`。
