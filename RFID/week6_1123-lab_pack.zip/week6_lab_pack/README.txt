Week 6｜電子錢包 × 小販機（離線交易與同步）

成果與驗收：去重、離線記帳、上線對帳、不可透支。

安裝：建立虛擬環境後 pip install -r requirements.txt；複製 .env.sample 為 .env。
建庫：mysql -u root -p < db/schema.sql；再導入 db/seed.sql。
啟動伺服器：python server/app_wallet.py （預設 http://127.0.0.1:8001）。
線上購買：python client/vending.py；再查餘額 /wallet/balance?uid=04aa11bb。
斷線：停止伺服器後再次執行 client/vending.py 會寫入 journal；恢復伺服器後跑 client/reconcile.py。
例外：重複 txn_no 應跳過；透支應回 insufficient。