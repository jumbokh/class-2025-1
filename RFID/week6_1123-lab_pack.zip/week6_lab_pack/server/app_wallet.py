import os, time
from flask import Flask, request, jsonify
import pymysql

DB_HOST=os.getenv("DB_HOST","localhost")
DB_PORT=int(os.getenv("DB_PORT","3306"))
DB_USER=os.getenv("DB_USER","root")
DB_PASS=os.getenv("DB_PASS","pass123")
DB_NAME=os.getenv("DB_NAME","rfid_iot")

def get_conn():
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASS,
                           database=DB_NAME, autocommit=False,
                           cursorclass=pymysql.cursors.DictCursor)

app = Flask(__name__)

def ensure_card(conn, uid):
    with conn.cursor() as c:
        c.execute("SELECT * FROM cards WHERE uid=%s FOR UPDATE", (uid,))
        row = c.fetchone()
        if not row:
            c.execute("INSERT INTO cards(uid, server_balance, last_txn_no, status) VALUES (%s,0,0,1)", (uid,))
            conn.commit()

def exists_txn(conn, uid, txn_no):
    with conn.cursor() as c:
        c.execute("SELECT 1 FROM txn WHERE uid=%s AND txn_no=%s", (uid, txn_no))
        return c.fetchone() is not None

def insert_txn_and_update_balance(conn, uid, amount, txn_no, typ):
    with conn.cursor() as c:
        c.execute("SELECT server_balance, last_txn_no FROM cards WHERE uid=%s FOR UPDATE", (uid,))
        row = c.fetchone()
        if not row:
            raise ValueError("card-not-found")
        bal = int(row["server_balance"])
        if bal + amount < 0:
            return False, "insufficient"
        ts = int(time.time())
        c.execute("""INSERT INTO txn(uid, type, amount, txn_no, ts, source)
                     VALUES (%s,%s,%s,%s,%s,'server')""",
                  (uid, typ, amount, txn_no, ts))
        c.execute("""UPDATE cards SET server_balance=server_balance+%s,
                                     last_txn_no=GREATEST(last_txn_no,%s)
                     WHERE uid=%s""", (amount, txn_no, uid))
        conn.commit()
        return True, {"balance": bal + amount, "ts": ts}

@app.post("/wallet/topup")
def wallet_topup():
    data = request.get_json(force=True)
    uid = (data.get("uid") or "").lower()
    amount = int(data.get("amount", 0))
    txn_no = int(data.get("txn_no") or time.time())
    if not uid or amount <= 0: return jsonify({"ok":False,"reason":"bad-args"}), 400

    conn = get_conn()
    try:
        ensure_card(conn, uid)
        if exists_txn(conn, uid, txn_no): conn.rollback(); return jsonify({"ok":False,"reason":"duplicate"})
        ok, info = insert_txn_and_update_balance(conn, uid, amount, txn_no, "TOPUP")
        if not ok: conn.rollback(); return jsonify({"ok":False,"reason":info})
        return jsonify({"ok":True, "uid":uid, "txn_no":txn_no, **info})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.post("/wallet/purchase")
def wallet_purchase():
    data = request.get_json(force=True)
    uid = (data.get("uid") or "").lower()
    items = data.get("items", [])
    txn_no = int(data.get("txn_no") or time.time())
    if not uid or not items: return jsonify({"ok":False,"reason":"bad-args"}), 400

    conn = get_conn()
    try:
        ensure_card(conn, uid)
        if exists_txn(conn, uid, txn_no): conn.rollback(); return jsonify({"ok":False,"reason":"duplicate"})

        total = 0
        with conn.cursor() as c:
            for it in items:
                sku = it["sku"]; qty = int(it.get("qty",1))
                c.execute("SELECT price FROM products WHERE sku=%s", (sku,))
                row = c.fetchone()
                if not row: conn.rollback(); return jsonify({"ok":False,"reason":f"sku-not-found:{sku}"})
                total += int(row["price"]) * qty

        ok, info = insert_txn_and_update_balance(conn, uid, -total, txn_no, "PURCHASE")
        if not ok: conn.rollback(); return jsonify({"ok":False,"reason":info})
        return jsonify({"ok":True, "uid":uid, "amount":-total, "txn_no":txn_no, **info})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.post("/wallet/reconcile")
def wallet_reconcile():
    payload = request.get_json(force=True)
    batch = payload.get("batch", [])
    applied = 0; skipped = 0
    conn = get_conn()
    try:
        for t in batch:
            uid = (t.get("uid") or "").lower()
            amount = int(t.get("amount", 0))
            txn_no = int(t.get("txn_no", 0))
            typ = t.get("type","ADJUST")
            if not uid or not txn_no: skipped += 1; continue
            ensure_card(conn, uid)
            if exists_txn(conn, uid, txn_no): conn.rollback(); skipped += 1; continue
            ok, info = insert_txn_and_update_balance(conn, uid, amount, txn_no, typ)
            if ok: applied += 1
            else: skipped += 1
        return jsonify({"ok":True, "applied":applied, "skipped":skipped})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.get("/wallet/balance")
def wallet_balance():
    uid = (request.args.get("uid") or "").lower()
    if not uid: return jsonify({"ok":False,"reason":"bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("SELECT server_balance FROM cards WHERE uid=%s", (uid,))
            row = c.fetchone()
        conn.commit()
        if not row: return jsonify({"ok":False,"reason":"not-found"}), 404
        return jsonify({"ok":True, "uid":uid, "server_balance": int(row["server_balance"])})
    finally:
        conn.close()

if __name__ == "__main__":
    host=os.getenv("HOST","0.0.0.0"); port=int(os.getenv("PORT","8001"))
    app.run(host=host, port=port, debug=True)
