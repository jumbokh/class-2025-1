USE rfid_iot;

INSERT INTO cards(uid, server_balance, last_txn_no, status) VALUES
('04aa11bb', 100, 0, 1),
('04bb22cc',  50, 0, 1)
ON DUPLICATE KEY UPDATE server_balance=VALUES(server_balance);

INSERT INTO products(sku, name, price) VALUES
('A01','Sandwich',25),
('A02','Coffee',15),
('A03','Tea',12)
ON DUPLICATE KEY UPDATE price=VALUES(price);
