import os, time, json, requests
from pathlib import Path

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8001")
STORE = Path(__file__).parent / "card_store.json"

def load_store(): return json.loads(STORE.read_text("utf-8"))

def save_store(d): STORE.write_text(json.dumps(d, indent=2), "utf-8")

def buy(items):
    d = load_store()
    txn_no = max(int(d["last_txn_no"]) + 1, int(time.time()))
    try:
        r = requests.post(f"{SERVER_URL}/wallet/purchase", json={"uid": d["uid"], "items": items, "txn_no": txn_no}, timeout=3)
        data = r.json()
        if data.get("ok"):
            d["last_txn_no"] = max(int(d["last_txn_no"]), int(txn_no))
            bal = requests.get(f"{SERVER_URL}/wallet/balance", params={"uid": d["uid"]}, timeout=3).json().get("server_balance", d["balance"])
            d["balance"] = bal
            save_store(d)
            print("線上購買成功:", data); return True
        else:
            raise RuntimeError(data.get("reason"))
    except Exception as e:
        price_map = {"A01":25,"A02":15,"A03":12}
        total = sum(price_map.get(it["sku"],0)*int(it.get("qty",1)) for it in items)
        if d["balance"] - total < 0:
            print("離線也不足額，取消"); return False
        d["balance"] -= total
        d["last_txn_no"] = max(int(d["last_txn_no"]), int(txn_no))
        d.setdefault("journal", []).append({"uid":d["uid"], "type":"PURCHASE",
                                            "amount":-total, "txn_no":int(txn_no), "ts":int(time.time())})
        save_store(d)
        print("伺服器無法連線，已離線記帳:", total, "txn_no=", txn_no)
        return True

if __name__ == "__main__":
    buy([{"sku":"A01","qty":1},{"sku":"A02","qty":2}])
