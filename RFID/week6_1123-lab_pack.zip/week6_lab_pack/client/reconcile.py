import os, json, requests
from pathlib import Path

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8001")
STORE = Path(__file__).parent / "card_store.json"

def load_store(): return json.loads(STORE.read_text("utf-8"))

def save_store(d): STORE.write_text(json.dumps(d, ensure_ascii=False, indent=2), "utf-8")

def reconcile():
    d = load_store()
    batch = d.get("journal", [])
    if not batch:
        print("無需對帳"); return
    try:
        r = requests.post(f"{SERVER_URL}/wallet/reconcile", json={"batch":batch}, timeout=5)
        data = r.json()
        print("對帳結果:", data)
        if data.get("ok"):
            d["journal"] = []
            bal = requests.get(f"{SERVER_URL}/wallet/balance", params={"uid": d["uid"]}, timeout=5).json().get("server_balance", d["balance"])
            d["balance"] = bal
            save_store(d)
    except Exception as e:
        print("對帳失敗:", e)

if __name__ == "__main__":
    reconcile()
