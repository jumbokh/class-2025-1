import json, time
from pathlib import Path

STORE = Path(__file__).parent / "card_store.json"

def load_store():
    if STORE.exists(): return json.loads(STORE.read_text("utf-8"))
    return {"uid":"04aa11bb","balance":100,"last_txn_no":0,"journal":[]}

def save_store(d): STORE.write_text(json.dumps(d, ensure_ascii=False, indent=2), "utf-8")

def next_txn_no(d): return max(int(d.get("last_txn_no",0))+1, int(time.time()))

def purchase_local(amount, txn_no=None):
    d = load_store()
    txn_no = txn_no or next_txn_no(d)
    if d["balance"] - amount < 0:
        print("本地餘額不足，取消購買"); return False
    d["balance"] -= amount
    d["last_txn_no"] = max(int(d["last_txn_no"]), int(txn_no))
    d["journal"].append({"uid":d["uid"], "type":"PURCHASE", "amount":-amount,
                         "txn_no":int(txn_no), "ts":int(time.time())})
    save_store(d)
    print("離線購買已記錄，txn_no=", txn_no)
    return True

if __name__ == "__main__":
    print("初始：", load_store())
