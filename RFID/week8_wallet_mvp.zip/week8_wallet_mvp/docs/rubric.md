# Week 8 評分規準（錢包 + 對帳）

- 功能（必做）：/wallet/topup, /wallet/purchase（不可透支）, /wallet/reconcile（去重 + 補帳）, /wallet/balance。
- 一致性：以 (uid, txn_no) 唯一鍵去重；事務中更新餘額。
- 觀測：/report/stats 近 24h 交易數（可擴充交易額統計）。
- 文件：README、.env.sample、schema/seed、測試腳本。
- Demo：60–90 秒展示線上購買、斷線離線購買、恢復對帳。

（完整分項版可沿用 rubrics 通用表）
