import os, pymysql
from dotenv import load_dotenv

load_dotenv()

DB_HOST=os.getenv("DB_HOST","localhost")
DB_PORT=int(os.getenv("DB_PORT","3306"))
DB_USER=os.getenv("DB_USER","root")
DB_PASS=os.getenv("DB_PASS","pass123")
DB_NAME=os.getenv("DB_NAME","rfid_iot")

def get_conn(autocommit=False):
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASS,
                           database=DB_NAME, autocommit=autocommit,
                           cursorclass=pymysql.cursors.DictCursor)
