import os, time
from flask import Flask, jsonify, request
from dotenv import load_dotenv
from utils.db import get_conn

load_dotenv()
app = Flask(__name__)

def ensure_card(conn, uid):
    with conn.cursor() as c:
        c.execute("SELECT 1 FROM cards WHERE uid=%s FOR UPDATE", (uid,))
        if not c.fetchone():
            c.execute("INSERT INTO cards(uid, server_balance, last_txn_no, status) VALUES (%s,0,0,1)", (uid,))

def exists_txn(conn, uid, txn_no):
    with conn.cursor() as c:
        c.execute("SELECT 1 FROM txn WHERE uid=%s AND txn_no=%s", (uid, txn_no))
        return c.fetchone() is not None

def insert_txn_and_update(conn, uid, amount, txn_no, typ):
    # amount: 正數=加值；負數=扣款
    with conn.cursor() as c:
        c.execute("SELECT server_balance, last_txn_no FROM cards WHERE uid=%s FOR UPDATE", (uid,))
        row = c.fetchone()
        if not row:
            raise ValueError("card-not-found")
        bal = int(row["server_balance"])
        if bal + amount < 0:
            return False, "insufficient"
        ts = int(time.time())
        c.execute("INSERT INTO txn(uid, type, amount, txn_no, ts, source) VALUES (%s,%s,%s,%s,%s,'server')",
                  (uid, typ, amount, txn_no, ts))
        c.execute("UPDATE cards SET server_balance=server_balance+%s, last_txn_no=GREATEST(last_txn_no,%s) WHERE uid=%s",
                  (amount, txn_no, uid))
    return True, {"balance": bal + amount, "ts": ts}

@app.get("/health")
def health():
    return jsonify({"ok": True, "ts": int(time.time())})

@app.get("/wallet/balance")
def wallet_balance():
    uid = (request.args.get("uid") or "").lower()
    if not uid: return jsonify({"ok": False, "reason": "bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("SELECT server_balance FROM cards WHERE uid=%s", (uid,))
            row = c.fetchone()
        conn.commit()
        if not row: return jsonify({"ok": False, "reason": "not-found"}), 404
        return jsonify({"ok": True, "uid": uid, "server_balance": int(row["server_balance"]) })
    finally:
        conn.close()

@app.post("/wallet/topup")
def wallet_topup():
    data = request.get_json(force=True)
    uid = (data.get("uid") or "").lower()
    amount = int(data.get("amount", 0))
    txn_no = int(data.get("txn_no") or time.time())
    if not uid or amount <= 0: return jsonify({"ok": False, "reason": "bad-args"}), 400

    conn = get_conn()
    try:
        ensure_card(conn, uid)
        if exists_txn(conn, uid, txn_no):
            conn.rollback(); return jsonify({"ok": False, "reason": "duplicate"})
        ok, info = insert_txn_and_update(conn, uid, amount, txn_no, "TOPUP")
        if not ok:
            conn.rollback(); return jsonify({"ok": False, "reason": info})
        conn.commit()
        return jsonify({"ok": True, "uid": uid, "txn_no": txn_no, **info})
    except Exception as e:
        conn.rollback(); return jsonify({"ok": False, "reason": str(e)}), 500
    finally:
        conn.close()

@app.post("/wallet/purchase")
def wallet_purchase():
    data = request.get_json(force=True)
    uid = (data.get("uid") or "").lower()
    amount = int(data.get("amount", 0))  # 正整數，將被扣款
    txn_no = int(data.get("txn_no") or time.time())
    if not uid or amount <= 0: return jsonify({"ok": False, "reason": "bad-args"}), 400

    conn = get_conn()
    try:
        ensure_card(conn, uid)
        if exists_txn(conn, uid, txn_no):
            conn.rollback(); return jsonify({"ok": False, "reason": "duplicate"})
        ok, info = insert_txn_and_update(conn, uid, -amount, txn_no, "PURCHASE")
        if not ok:
            conn.rollback(); return jsonify({"ok": False, "reason": info})
        conn.commit()
        return jsonify({"ok": True, "uid": uid, "txn_no": txn_no, **info})
    except Exception as e:
        conn.rollback(); return jsonify({"ok": False, "reason": str(e)}), 500
    finally:
        conn.close()

@app.post("/wallet/reconcile")
def wallet_reconcile():
    payload = request.get_json(force=True)
    batch = payload.get("batch", [])
    applied = 0; skipped = 0
    conn = get_conn()
    try:
        for t in batch:
            uid = (t.get("uid") or "").lower()
            typ = t.get("type", "ADJUST")
            amount = int(t.get("amount", 0))
            txn_no = int(t.get("txn_no") or 0)
            if not uid or not txn_no:
                skipped += 1; continue
            ensure_card(conn, uid)
            if exists_txn(conn, uid, txn_no):
                conn.rollback(); skipped += 1; continue
            ok, info = insert_txn_and_update(conn, uid, amount, txn_no, typ)
            if ok: applied += 1
            else: skipped += 1
        conn.commit()
        return jsonify({"ok": True, "applied": applied, "skipped": skipped})
    except Exception as e:
        conn.rollback(); return jsonify({"ok": False, "reason": str(e)}), 500
    finally:
        conn.close()

@app.get("/report/stats")
def report_stats():
    try:
        now = int(time.time()); day_ago = now - 24*3600
        conn = get_conn()
        with conn.cursor() as c:
            c.execute("SELECT COUNT(*) AS cnt FROM txn WHERE ts BETWEEN %s AND %s", (day_ago, now))
            cnt = c.fetchone()["cnt"]
        conn.commit(); conn.close()
        return jsonify({"ok": True, "window": "24h", "transactions": int(cnt)})
    except Exception as e:
        return jsonify({"ok": False, "reason": str(e)}), 500

if __name__ == "__main__":
    host=os.getenv("HOST","0.0.0.0")
    port=int(os.getenv("PORT","8010"))
    app.run(host=host, port=port, debug=True)
