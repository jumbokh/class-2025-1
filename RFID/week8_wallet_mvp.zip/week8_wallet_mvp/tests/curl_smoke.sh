#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8010}

echo "[1/5] health"
curl -sS ${BASE}/health | jq . || true

echo "[2/5] topup 10 to 04aa11bb"
curl -sS -X POST ${BASE}/wallet/topup -H "Content-Type: application/json"   -d '{"uid":"04aa11bb","amount":10,"txn_no":1730600100}' | jq . || true

echo "[3/5] purchase 5"
curl -sS -X POST ${BASE}/wallet/purchase -H "Content-Type: application/json"   -d '{"uid":"04aa11bb","amount":5,"txn_no":1730600200}' | jq . || true

echo "[4/5] balance"
curl -sS "${BASE}/wallet/balance?uid=04aa11bb" | jq . || true

echo "[5/5] stats (24h)"
curl -sS ${BASE}/report/stats | jq . || true

echo "Done."
