import os, requests, streamlit as st

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8010")
st.set_page_config(page_title="Wallet MVP 看板", layout="wide")
st.title("Week 8｜錢包 + 對帳 MVP")

col1, col2 = st.columns(2)

with col1:
    st.subheader("健康檢查")
    try:
        data = requests.get(f"{SERVER_URL}/health", timeout=5).json()
        st.write(data)
    except Exception as e:
        st.error(f"health 失敗：{e}")

with col2:
    st.subheader("近 24h 交易數")
    try:
        stats = requests.get(f"{SERVER_URL}/report/stats", timeout=5).json()
        st.write(stats)
    except Exception as e:
        st.error(f"stats 失敗：{e}")

st.caption("可擴充：交易額折線圖、失敗交易、每小時分布等等。")
