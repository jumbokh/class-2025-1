USE rfid_iot;

INSERT INTO cards(uid, server_balance, last_txn_no, status) VALUES
('04aa11bb', 100, 0, 1),
('04bb22cc',  50, 0, 1)
ON DUPLICATE KEY UPDATE server_balance=VALUES(server_balance);
