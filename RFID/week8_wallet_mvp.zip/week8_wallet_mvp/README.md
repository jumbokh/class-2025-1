# Week 8｜錢包 + 對帳 MVP（可直接跑）

本專案提供「電子錢包購買（不可透支）」與「離線 journal 對帳」的最小可行實作，對應你在第 6 週的練習。

## 0) 快速開始（5 步）
1. 安裝依賴與設定環境變數
   ```bash
   pip install -r requirements.txt
   cp .env.sample .env
   ```
2. 建資料庫與種子資料
   ```bash
   mysql -u root -p < db/schema.sql
   mysql -u root -p < db/seed.sql
   ```
3. 啟動伺服器
   ```bash
   python server/app.py
   # 健康檢查：http://127.0.0.1:8010/health
   ```
4. （可選）啟動看板
   ```bash
   streamlit run web/dashboard.py
   ```
5. 小試身手（線上購買/對帳）
   ```bash
   bash tests/curl_smoke.sh
   ```

## 1) 主要 API
- `POST /wallet/topup {uid, amount, [txn_no]}`：儲值（`amount>0`），以 `(uid, txn_no)` 去重。
- `POST /wallet/purchase {uid, amount, [txn_no]}`：購買（`amount>0`），不可透支。
- `POST /wallet/reconcile {batch:[{uid, type, amount, txn_no, ts}]}`：離線 journal 批次補登（逐筆去重/檢核餘額）。
- `GET  /wallet/balance?uid=...`：查餘額。
- `GET  /report/stats`：近 24 小時交易數。

## 2) 客戶端（離線優先）
- `client/kiosk.py`：先嘗試線上購買；失敗則寫本地 `journal`。
- `client/reconcile.py`：把 `journal` 批次送去 `/wallet/reconcile`，成功後清空。

## 3) 測試腳本
- `tests/curl_smoke.sh`：健康檢查、儲值、購買、查餘額與 24h 統計。

> Schema 設計重點：`txn(uid, txn_no)` 唯一索引去重；`cards.server_balance` 在事務中更新，確保不可透支。
