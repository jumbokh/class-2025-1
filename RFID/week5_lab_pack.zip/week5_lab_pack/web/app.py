import os, requests, pandas as pd, streamlit as st

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8000")

st.set_page_config(page_title="RFID 即時看板", layout="wide")
st.title("RFID 門禁/出缺勤 即時看板")

col1, col2 = st.columns(2)

with col1:
    try:
        now_in = requests.get(f"{SERVER_URL}/report/now_in", timeout=5).json()
        st.metric("目前在線人數", now_in.get("count",0))
        st.write("UIDs:", now_in.get("uids", []))
    except Exception as e:
        st.error(f"now_in 失敗：{e}")

with col2:
    try:
        recent = requests.get(f"{SERVER_URL}/report/recent", timeout=5).json()
        st.subheader("最近 20 筆")
        st.dataframe(pd.DataFrame(recent))
    except Exception as e:
        st.error(f"recent 失敗：{e}")

st.divider()
try:
    today = requests.get(f"{SERVER_URL}/report/today_count", timeout=5).json()
    if today:
        df = pd.DataFrame(today)
        df["hour"] = df["hour"].astype(int)
        df = df.sort_values("hour")
        st.subheader("今日刷卡數（每小時）")
        st.line_chart(df.set_index("hour")["cnt"])
    else:
        st.info("今日尚無資料")
except Exception as e:
    st.error(f"今日統計失敗：{e}")

st.caption("每 5 秒自動刷新（按 R 手動刷新）")
