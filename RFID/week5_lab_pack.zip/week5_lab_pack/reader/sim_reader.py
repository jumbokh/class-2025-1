import os, time, json, random
import paho.mqtt.client as mqtt

MQTT_HOST=os.getenv("MQTT_HOST","localhost")
MQTT_PORT=int(os.getenv("MQTT_PORT","1883"))
TOPIC_ENTRY=os.getenv("MQTT_TOPIC_ENTRY","rfid/door/entry")
READER_ID=os.getenv("READER_ID","gateA")

def random_uid():
    return "04" + "".join(f"{random.randint(0,255):02x}" for _ in range(3))

if __name__ == "__main__":
    client = mqtt.Client()
    client.connect(MQTT_HOST, MQTT_PORT, 60)
    print("Sim reader started. Ctrl+C to stop.")
    while True:
        uid = random.choice(["04aa11bb","04bb22cc", random_uid()])
        payload = {"uid": uid, "ts": int(time.time()), "reader_id": READER_ID}
        client.publish(TOPIC_ENTRY, json.dumps(payload))
        print("Published:", payload)
        time.sleep(2)
