import os, time, json
from smartcard.System import readers
from smartcard.Exceptions import NoCardException
import paho.mqtt.client as mqtt

MQTT_HOST=os.getenv("MQTT_HOST","localhost")
MQTT_PORT=int(os.getenv("MQTT_PORT","1883"))
TOPIC_ENTRY=os.getenv("MQTT_TOPIC_ENTRY","rfid/door/entry")
READER_ID=os.getenv("READER_ID","gateA")

def get_uid(connection):
    # APDU to get UID for ACR122U: FF CA 00 00 00
    data, sw1, sw2 = connection.transmit([0xFF,0xCA,0x00,0x00,0x00])
    if sw1 == 0x90 and sw2 == 0x00:
        return "".join(f"{b:02x}" for b in data)
    return None

if __name__ == "__main__":
    rlist = readers()
    if not rlist:
        print("No readers found.")
        raise SystemExit(1)
    r = rlist[0]
    print("Using reader:", r)

    client = mqtt.Client()
    client.connect(MQTT_HOST, MQTT_PORT, 60)

    while True:
        try:
            conn = r.createConnection()
            conn.connect()
            uid = get_uid(conn)
            if uid:
                payload = {"uid": uid, "ts": int(time.time()), "reader_id": READER_ID}
                client.publish(TOPIC_ENTRY, json.dumps(payload))
                print("Published:", payload)
                time.sleep(1.0)
        except NoCardException:
            time.sleep(0.2)
        except Exception as e:
            print("Error:", e)
            time.sleep(1.0)
