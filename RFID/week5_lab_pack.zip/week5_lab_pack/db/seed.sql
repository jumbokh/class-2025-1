USE rfid_iot;
-- 將 uid 改成你自己的卡片 UID 或測試 UID
INSERT INTO users(uid,name,dept,status) VALUES
('04aa11bb','Student A','AI Dept',1),
('04bb22cc','Student B','AI Dept',1)
ON DUPLICATE KEY UPDATE name=VALUES(name), dept=VALUES(dept), status=VALUES(status);
