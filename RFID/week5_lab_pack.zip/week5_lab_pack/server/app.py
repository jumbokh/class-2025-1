import os, time
from flask import Flask, request, jsonify
import pymysql

DB_HOST=os.getenv("DB_HOST","localhost")
DB_PORT=int(os.getenv("DB_PORT","3306"))
DB_USER=os.getenv("DB_USER","root")
DB_PASS=os.getenv("DB_PASS","pass123")
DB_NAME=os.getenv("DB_NAME","rfid_iot")
ANTI_PASSBACK_SECONDS=int(os.getenv("ANTI_PASSBACK_SECONDS","10"))

def db():
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASS,
                           database=DB_NAME, autocommit=True,
                           cursorclass=pymysql.cursors.DictCursor)

def is_whitelisted(uid):
    with db().cursor() as c:
        c.execute("SELECT 1 FROM users WHERE uid=%s AND status=1", (uid,))
        return c.fetchone() is not None

def last_state(uid):
    with db().cursor() as c:
        c.execute("SELECT direction, ts FROM access_log WHERE uid=%s ORDER BY ts DESC LIMIT 1", (uid,))
        row = c.fetchone()
        return (row["direction"], int(row["ts"])) if row else (None, 0)

def insert_log(uid, direction, ts, reader_id):
    with db().cursor() as c:
        c.execute("INSERT INTO access_log(uid, direction, ts, reader_id) VALUES (%s,%s,%s,%s)",
                  (uid, direction, ts, reader_id))

def decide_direction(last_dir):
    return "OUT" if last_dir == "IN" else "IN"

app = Flask(__name__)

@app.post("/auth/checkCard")
def check_card():
    data = request.get_json(force=True)
    uid = (data.get("uid") or "").lower()
    reader_id = data.get("reader_id","gateA")
    ts = int(data.get("ts", time.time()))
    if not uid:
        return jsonify({"allow": False, "dir": None, "reason":"no-uid"}), 400

    if not is_whitelisted(uid):
        return jsonify({"allow": False, "dir": None, "reason":"not-whitelisted"})

    last_dir, last_ts = last_state(uid)
    new_dir = decide_direction(last_dir) if last_dir else "IN"

    if last_dir == new_dir and (ts - int(last_ts)) < ANTI_PASSBACK_SECONDS:
        return jsonify({"allow": False, "dir": new_dir, "reason":"anti-passback"})

    insert_log(uid, new_dir, ts, reader_id)
    return jsonify({"allow": True, "dir": new_dir, "reason":"ok"})

@app.get("/report/now_in")
def report_now_in():
    with db().cursor() as c:
        c.execute("""
        SELECT x.uid
        FROM (
          SELECT uid,
                 MAX(CASE WHEN direction='IN' THEN ts ELSE 0 END) AS last_in,
                 MAX(CASE WHEN direction='OUT' THEN ts ELSE 0 END) AS last_out
          FROM access_log GROUP BY uid
        ) x WHERE x.last_in > x.last_out
        """)
        rows = c.fetchall()
    return jsonify({"count": len(rows), "uids": [r["uid"] for r in rows]})

@app.get("/report/recent")
def report_recent():
    with db().cursor() as c:
        c.execute("SELECT uid, direction, ts, reader_id FROM access_log ORDER BY ts DESC LIMIT 20")
        rows = c.fetchall()
    return jsonify(rows)

@app.get("/report/today_count")
def report_today_count():
    with db().cursor() as c:
        c.execute("""
        SELECT FROM_UNIXTIME(ts, '%H') AS hour, COUNT(*) AS cnt
        FROM access_log
        WHERE DATE(FROM_UNIXTIME(ts)) = CURDATE()
        GROUP BY hour ORDER BY hour
        """)
        rows = c.fetchall()
    return jsonify(rows)

if __name__ == "__main__":
    host=os.getenv("HOST","0.0.0.0")
    port=int(os.getenv("PORT","8000"))
    app.run(host=host, port=port, debug=True)
