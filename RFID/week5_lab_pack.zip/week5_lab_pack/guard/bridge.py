import os, json, requests
import paho.mqtt.client as mqtt

MQTT_HOST=os.getenv("MQTT_HOST","localhost")
MQTT_PORT=int(os.getenv("MQTT_PORT","1883"))
TOPIC_ENTRY=os.getenv("MQTT_TOPIC_ENTRY","rfid/door/entry")
TOPIC_ACK=os.getenv("MQTT_TOPIC_ACK","rfid/door/ack")
SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8000")

def on_connect(client, userdata, flags, rc, properties=None):
    print("MQTT connected", rc)
    client.subscribe(TOPIC_ENTRY)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        r = requests.post(f"{SERVER_URL}/auth/checkCard", json=payload, timeout=5)
        data = r.json()
        ack = { **payload, **data }
        client.publish(TOPIC_ACK, json.dumps(ack), qos=0)
        print("ACK:", ack)
    except Exception as e:
        print("ERR:", e)

if __name__ == "__main__":
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_HOST, MQTT_PORT, 60)
    client.loop_forever()
