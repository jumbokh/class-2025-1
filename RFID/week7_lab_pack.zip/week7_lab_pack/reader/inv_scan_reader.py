import os, time, requests
from smartcard.System import readers
from smartcard.Exceptions import NoCardException

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8002")

def get_uid(connection):
    data, sw1, sw2 = connection.transmit([0xFF,0xCA,0x00,0x00,0x00])
    if sw1 == 0x90 and sw2 == 0x00:
        return "".join(f"{b:02x}" for b in data)
    return None

def main():
    sid = int(input("session_id：").strip())
    rlist = readers()
    if not rlist:
        print("找不到讀卡機"); return
    r = rlist[0]
    print("使用讀卡機：", r)
    while True:
        try:
            conn = r.createConnection(); conn.connect()
            uid = get_uid(conn)
            if uid:
                ts = int(time.time())
                rr = requests.post(f"{SERVER_URL}/inventory/scan", json={"session_id": sid, "tag_uid": uid, "ts": ts, "reader_id":"acr122u"})
                print("掃描", uid, "→", rr.status_code, rr.text)
                time.sleep(1.0)
        except NoCardException:
            time.sleep(0.2)
        except Exception as e:
            print("ERR:", e); time.sleep(1.0)

if __name__ == "__main__":
    main()
