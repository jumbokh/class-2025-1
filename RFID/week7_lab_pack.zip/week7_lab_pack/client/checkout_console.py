import os, time, requests

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8002")

def main():
    borrower = input("借用人 UID（users.uid）：").strip().lower()
    tag = input("資產 tag_uid：").strip().lower()
    due_days = int(input("借用天數（預設7）：") or "7")
    op_no = int(time.time())
    r = requests.post(f"{SERVER_URL}/loan/checkout", json={
        "borrower_uid": borrower, "tag_uid": tag, "due_days": due_days, "op_no": op_no
    })
    print("回應：", r.status_code, r.text)

if __name__ == "__main__":
    main()
