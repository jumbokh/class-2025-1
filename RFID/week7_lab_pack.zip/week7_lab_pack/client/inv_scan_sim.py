import os, time, random, requests

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8002")

SAMPLE_TAGS = ["A100aa01","A100aa02","B200bb01","B200bb02","C300cc01"]

def main():
    sid = int(input("session_id：").strip())
    while True:
        tag = random.choice(SAMPLE_TAGS)
        ts = int(time.time())
        r = requests.post(f"{SERVER_URL}/inventory/scan", json={"session_id": sid, "tag_uid": tag, "ts": ts, "reader_id":"simR"})
        print("掃描", tag, "→", r.status_code, r.text)
        time.sleep(2)

if __name__ == "__main__":
    main()
