import os, time, requests

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8002")

def main():
    tag = input("歸還 tag_uid：").strip().lower()
    condition_in = input("歸還狀況（可空白）：")
    op_no = int(time.time())
    r = requests.post(f"{SERVER_URL}/loan/return", json={
        "tag_uid": tag, "condition_in": condition_in, "op_no": op_no
    })
    print("回應：", r.status_code, r.text)

if __name__ == "__main__":
    main()
