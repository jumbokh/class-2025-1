import os, requests

SERVER_URL=os.getenv("SERVER_URL","http://127.0.0.1:8002")

def main():
    loc = input("盤點地點（例如：Lab-A）：").strip()
    r = requests.post(f"{SERVER_URL}/inventory/start", json={"location": loc})
    print("回應：", r.status_code, r.text)

if __name__ == "__main__":
    main()
