CREATE DATABASE IF NOT EXISTS rfid_iot DEFAULT CHARACTER SET utf8mb4;
USE rfid_iot;

-- 資產主檔
CREATE TABLE IF NOT EXISTS assets(
  tag_uid VARCHAR(32) PRIMARY KEY,
  name VARCHAR(64),
  category VARCHAR(32),
  status ENUM('IN','OUT') NOT NULL DEFAULT 'IN',
  last_seen_ts BIGINT DEFAULT 0
);

-- 借還紀錄（以 op_no 去重）
CREATE TABLE IF NOT EXISTS loans(
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  tag_uid VARCHAR(32) NOT NULL,
  borrower_uid VARCHAR(32) NOT NULL,
  checkout_ts BIGINT NOT NULL,
  due_ts BIGINT NOT NULL,
  return_ts BIGINT NULL,
  condition_out VARCHAR(64) NULL,
  condition_in  VARCHAR(64) NULL,
  op_no BIGINT NOT NULL,
  notes VARCHAR(255) NULL
);
CREATE UNIQUE INDEX uniq_loans_opno ON loans(op_no);
CREATE INDEX idx_loans_open ON loans(tag_uid, return_ts);

-- 盤點
CREATE TABLE IF NOT EXISTS inventory_session(
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  location VARCHAR(64),
  started_ts BIGINT NOT NULL,
  ended_ts BIGINT NULL,
  notes VARCHAR(255) NULL
);

CREATE TABLE IF NOT EXISTS inventory_event(
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  session_id BIGINT NOT NULL,
  tag_uid VARCHAR(32) NOT NULL,
  ts BIGINT NOT NULL,
  reader_id VARCHAR(32)
);
CREATE UNIQUE INDEX uniq_inv_once ON inventory_event(session_id, tag_uid);
