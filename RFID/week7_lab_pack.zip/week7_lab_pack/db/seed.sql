USE rfid_iot;

-- 使用第 5 週的 users 表（若不存在請先建立）
INSERT INTO assets(tag_uid, name, category, status) VALUES
('A100aa01','Laptop-01','IT','IN'),
('A100aa02','Laptop-02','IT','IN'),
('B200bb01','Camera-01','Media','IN'),
('B200bb02','Camera-02','Media','IN'),
('C300cc01','Tripod-01','Media','IN')
ON DUPLICATE KEY UPDATE name=VALUES(name), category=VALUES(category);
