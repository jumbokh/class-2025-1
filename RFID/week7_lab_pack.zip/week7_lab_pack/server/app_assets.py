import os, time
from flask import Flask, request, jsonify
import pymysql

DB_HOST=os.getenv("DB_HOST","localhost")
DB_PORT=int(os.getenv("DB_PORT","3306"))
DB_USER=os.getenv("DB_USER","root")
DB_PASS=os.getenv("DB_PASS","pass123")
DB_NAME=os.getenv("DB_NAME","rfid_iot")

def get_conn():
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASS,
                           database=DB_NAME, autocommit=False,
                           cursorclass=pymysql.cursors.DictCursor)

app = Flask(__name__)

# ---------- Assets ----------
@app.post("/assets/register")
def assets_register():
    data = request.get_json(force=True)
    tag_uid = (data.get("tag_uid") or "").lower()
    name = data.get("name") or ""
    category = data.get("category") or ""
    if not tag_uid: return jsonify({"ok":False,"reason":"bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("INSERT INTO assets(tag_uid,name,category,status,last_seen_ts) VALUES(%s,%s,%s,'IN',0)                        ON DUPLICATE KEY UPDATE name=VALUES(name), category=VALUES(category)",
                      (tag_uid, name, category))
        conn.commit()
        return jsonify({"ok":True, "tag_uid":tag_uid})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.get("/assets/list")
def assets_list():
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("SELECT tag_uid,name,category,status,last_seen_ts FROM assets ORDER BY tag_uid")
            rows = c.fetchall()
        conn.commit()
        return jsonify(rows)
    finally:
        conn.close()

# ---------- Loans ----------
def has_open_loan(conn, tag_uid):
    with conn.cursor() as c:
        c.execute("SELECT id, borrower_uid, checkout_ts, due_ts FROM loans WHERE tag_uid=%s AND return_ts IS NULL",
                  (tag_uid,))
        return c.fetchone()

@app.post("/loan/checkout")
def loan_checkout():
    data = request.get_json(force=True)
    tag_uid = (data.get("tag_uid") or "").lower()
    borrower_uid = (data.get("borrower_uid") or "").lower()
    due_days = int(data.get("due_days", 7))
    op_no = int(data.get("op_no") or time.time())
    condition_out = data.get("condition_out") or ""
    if not tag_uid or not borrower_uid: return jsonify({"ok":False,"reason":"bad-args"}), 400

    now = int(time.time())
    due_ts = now + due_days*24*3600

    conn = get_conn()
    try:
        with conn.cursor() as c:
            # 去重
            c.execute("SELECT 1 FROM loans WHERE op_no=%s", (op_no,))
            if c.fetchone():
                conn.rollback(); return jsonify({"ok":False,"reason":"duplicate-op"})
            # 不可重複外借
            if has_open_loan(conn, tag_uid):
                conn.rollback(); return jsonify({"ok":False,"reason":"already-out"})
            # 記錄借出
            c.execute("""INSERT INTO loans(tag_uid, borrower_uid, checkout_ts, due_ts, return_ts, condition_out, op_no)
                         VALUES (%s,%s,%s,%s,NULL,%s,%s)""",
                      (tag_uid, borrower_uid, now, due_ts, condition_out, op_no))
            # 更新資產狀態
            c.execute("UPDATE assets SET status='OUT' WHERE tag_uid=%s", (tag_uid,))
        conn.commit()
        return jsonify({"ok":True, "tag_uid":tag_uid, "borrower_uid":borrower_uid, "due_ts":due_ts, "op_no":op_no})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.post("/loan/return")
def loan_return():
    data = request.get_json(force=True)
    tag_uid = (data.get("tag_uid") or "").lower()
    condition_in = data.get("condition_in") or ""
    op_no = int(data.get("op_no") or time.time())
    if not tag_uid: return jsonify({"ok":False,"reason":"bad-args"}), 400
    now = int(time.time())

    conn = get_conn()
    try:
        with conn.cursor() as c:
            # 去重：同樣 op_no
            c.execute("SELECT 1 FROM loans WHERE op_no=%s", (op_no,))
            if c.fetchone():
                conn.rollback(); return jsonify({"ok":False,"reason":"duplicate-op"})
            # 找開放中的借出
            c.execute("SELECT id FROM loans WHERE tag_uid=%s AND return_ts IS NULL ORDER BY checkout_ts DESC LIMIT 1",
                      (tag_uid,))
            row = c.fetchone()
            if not row:
                conn.rollback(); return jsonify({"ok":False,"reason":"no-open-loan"})
            loan_id = row["id"]
            c.execute("UPDATE loans SET return_ts=%s, condition_in=%s, op_no=%s WHERE id=%s",
                      (now, condition_in, op_no, loan_id))
            c.execute("UPDATE assets SET status='IN' WHERE tag_uid=%s", (tag_uid,))
        conn.commit()
        return jsonify({"ok":True, "tag_uid":tag_uid, "return_ts":now, "op_no":op_no})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.get("/loan/status")
def loan_status():
    tag_uid = (request.args.get("tag_uid") or "").lower()
    if not tag_uid: return jsonify({"ok":False,"reason":"bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("""SELECT a.tag_uid,a.name,a.status,
                         (SELECT borrower_uid FROM loans WHERE tag_uid=a.tag_uid AND return_ts IS NULL ORDER BY checkout_ts DESC LIMIT 1) AS borrower_uid,
                         (SELECT due_ts FROM loans WHERE tag_uid=a.tag_uid AND return_ts IS NULL ORDER BY checkout_ts DESC LIMIT 1) AS due_ts
                         FROM assets a WHERE a.tag_uid=%s""", (tag_uid,))
            row = c.fetchone()
        conn.commit()
        if not row: return jsonify({"ok":False,"reason":"not-found"}), 404
        return jsonify({"ok":True, **row})
    finally:
        conn.close()

@app.get("/report/overdue")
def report_overdue():
    now = int(time.time())
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("""SELECT tag_uid, borrower_uid, checkout_ts, due_ts
                         FROM loans WHERE return_ts IS NULL AND due_ts < %s
                         ORDER BY due_ts ASC""", (now,))
            rows = c.fetchall()
        conn.commit()
        return jsonify(rows)
    finally:
        conn.close()

# ---------- Inventory ----------
@app.post("/inventory/start")
def inv_start():
    data = request.get_json(force=True)
    location = data.get("location") or ""
    now = int(time.time())
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("INSERT INTO inventory_session(location, started_ts) VALUES(%s,%s)", (location, now))
            c.execute("SELECT LAST_INSERT_ID() AS sid")
            sid = c.fetchone()["sid"]
        conn.commit()
        return jsonify({"ok":True, "session_id": int(sid)})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.post("/inventory/scan")
def inv_scan():
    data = request.get_json(force=True)
    session_id = int(data.get("session_id", 0))
    tag_uid = (data.get("tag_uid") or "").lower()
    reader_id = data.get("reader_id") or "r1"
    ts = int(data.get("ts") or time.time())
    if not session_id or not tag_uid: return jsonify({"ok":False,"reason":"bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            # 只記一次（去重），重掃視為更新 last_seen_ts
            c.execute("SELECT 1 FROM inventory_event WHERE session_id=%s AND tag_uid=%s", (session_id, tag_uid))
            if not c.fetchone():
                c.execute("INSERT INTO inventory_event(session_id, tag_uid, ts, reader_id) VALUES(%s,%s,%s,%s)",
                          (session_id, tag_uid, ts, reader_id))
            else:
                c.execute("UPDATE inventory_event SET ts=%s, reader_id=%s WHERE session_id=%s AND tag_uid=%s",
                          (ts, reader_id, session_id, tag_uid))
            c.execute("UPDATE assets SET last_seen_ts=%s WHERE tag_uid=%s", (ts, tag_uid))
        conn.commit()
        return jsonify({"ok":True})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

@app.get("/inventory/summary")
def inv_summary():
    session_id = int(request.args.get("session_id", 0))
    if not session_id: return jsonify({"ok":False,"reason":"bad-args"}), 400
    conn = get_conn()
    try:
        with conn.cursor() as c:
            # 已掃到
            c.execute("SELECT tag_uid FROM inventory_event WHERE session_id=%s", (session_id,))
            present = {r["tag_uid"] for r in c.fetchall()}
            # 預期在庫（IN）
            c.execute("SELECT tag_uid FROM assets WHERE status='IN'")
            expected = {r["tag_uid"] for r in c.fetchall()}
            # 外借中
            c.execute("SELECT tag_uid FROM assets WHERE status='OUT'")
            out = {r["tag_uid"] for r in c.fetchall()}
        conn.commit()
        missing = sorted(list(expected - present))
        present_l = sorted(list(present))
        out_l = sorted(list(out))
        return jsonify({"session_id":session_id,
                        "present_count": len(present_l), "present": present_l,
                        "missing_count": len(missing),   "missing": missing,
                        "out_count": len(out_l),         "out": out_l})
    finally:
        conn.close()

@app.post("/inventory/end")
def inv_end():
    data = request.get_json(force=True)
    session_id = int(data.get("session_id", 0))
    if not session_id: return jsonify({"ok":False,"reason":"bad-args"}), 400
    now = int(time.time())
    conn = get_conn()
    try:
        with conn.cursor() as c:
            c.execute("UPDATE inventory_session SET ended_ts=%s WHERE id=%s", (now, session_id))
        conn.commit()
        return jsonify({"ok":True, "ended_ts":now})
    except Exception as e:
        conn.rollback(); return jsonify({"ok":False,"reason":str(e)}), 500
    finally:
        conn.close()

if __name__ == "__main__":
    host=os.getenv("HOST","0.0.0.0"); port=int(os.getenv("PORT","8002"))
    app.run(host=host, port=port, debug=True)
